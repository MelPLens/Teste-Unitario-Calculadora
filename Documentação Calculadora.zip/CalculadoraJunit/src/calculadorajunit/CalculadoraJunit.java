package calculadorajunit; // Substitua "com.suaempresa" pelo seu pacote

/**
 * Calculadora - Uma classe para realizar operações matemáticas simples.
 *
 * @autor Seu Nome
 * @desde 2023-10-30
 * @versão 1.0
 */
public class CalculadoraJunit {

    /**
     * Soma - Classe interna para realizar operações de soma.
     */
    public static class Soma {

        /**
         * Realiza a soma de dois números inteiros.
         *
         * @param a O primeiro número a ser somado.
         * @param b O segundo número a ser somado.
         * @return O resultado da soma de a e b.
         */
        public static int somar(int a, int b) {
            return a + b;
        }
    }

    /**
     * Subtracao - Classe interna para realizar operações de subtração.
     */
    public static class Subtracao {

        /**
         * Realiza a subtração de dois números inteiros.
         *
         * @param a O número do qual subtrair.
         * @param b O número a ser subtraído.
         * @return O resultado da subtração de a por b.
         */
        public static int subtrair(int a, int b) {
            return a - b;
        }
    }

    /**
     * Divisao - Classe interna para realizar operações de divisão.
     */
    public static class Divisao {

        /**
         * Realiza a divisão de dois números inteiros.
         *
         * @param a O número a ser dividido.
         * @param b O número pelo qual dividir.
         * @return O resultado da divisão de a por b.
         * @throws IllegalArgumentException Se b for igual a zero.
         */
        public static int dividir(int a, int b) {
            if (b != 0) {
                return a / b;
            } else {
                throw new IllegalArgumentException("Divisor não pode ser zero.");
            }
        }
    }

    /**
     * Multiplicacao - Classe interna para realizar operações de multiplicação.
     */
    public static class Multiplicacao {

        /**
         * Realiza a multiplicação de dois números inteiros.
         *
         * @param a O primeiro número a ser multiplicado.
         * @param b O segundo número a ser multiplicado.
         * @return O resultado da multiplicação de a e b.
         */
        public static int multiplicar(int a, int b) {
            return a * b;
        }
    }
}
